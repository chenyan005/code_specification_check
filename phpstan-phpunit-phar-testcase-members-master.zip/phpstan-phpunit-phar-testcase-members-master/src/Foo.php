<?php

namespace TimeToCode;

class Foo
{

}
