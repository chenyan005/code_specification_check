# Type hints
# variable_name:type = value

idade:int = "rodrigo"