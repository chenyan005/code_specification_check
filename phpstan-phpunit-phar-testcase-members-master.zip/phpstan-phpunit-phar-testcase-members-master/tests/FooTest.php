<?php

namespace TimeToCode\Tests;

use PHPUnit\Framework\TestCase;
use TimeToCode\Foo;

class FooTest extends TestCase
{
    public Foo $foo;
}
